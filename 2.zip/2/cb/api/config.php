<?php
$db = mysql_connect('localhost', 'root', '') or die('connection fail!!!');
mysql_select_db('cb', $db);
?>